-- Warp by hugeblank - June 2022
-- Made to feature Allium at BlanketCon
-- Adds the /warp and /waila command

local BlockPos = java.import("net.minecraft.util.math.BlockPos")
local Registry = java.import("Registry")
local CommandManager = java.import("CommandManager")
local arguments = command.arguments

--[[ SETUP ]]--

local itemsPerPage = 18 -- 20-2 for the header and footer

local warps
local locked

-- 2 Utility functions for saving and loading warp/lock files
local function getTable(table, filename)
    if fs.exists(filename) then
        local s, e = pcall(function()
            local file = fs.open(filename, "r")
            table = json.fromJson(file:readAll())
            file:close()
        end)
        if not s then
            print("Could not load file: "..filename.." "..e)
        end
    else
        table = {}
    end
    return table
end

local function flushTable(table, filename)
    local file = fs.open(filename, "w")
    file:write(json.toJson(table))
    file:close()
end

-- Initializes warps, pulling from the json if it exists, and creating a new table otherwise
local function getWarps()
    if not warps then
        warps = getTable(warps, "warps.json")
    end
    return warps
end

-- Does the same for locked players
local function getLocked()
    if not locked then
        locked = getTable(locked, "locked.json")
    end
    return locked
end

-- Caches the warp list, meant to be used every time a warp gets created, modified or removed.
local function flushWarps()
    flushTable(warps, "warps.json")
end

-- Does the same for the locked players table
local function flushLocked()
    flushTable(locked, "locked.json")
end

--[[ WARP COMMAND ]]

-- Create the command builder
local builder = CommandManager.literal("warp")

-- Wrapper function for sending parsed messages to player
local function sendFeedback(context, message)
    context:getSource():sendFeedback(texts.parse(message), false)
end

-- Function for handling the creation of next/prev page arrows and their action
local function makeArrow(char, next, maxPage)
    if next > maxPage or next < 1 then
        return "<gray>"..char.."</gray>"
    end
    return "<bold><gold><click:run_command:'/warp list "..tostring(next).."'>"..char.."</click></gold></bold>"
end

-- Function for generating the warp list depending on the page
local function listWarps(context, page)
    local list = getWarps()
    local maxPage = math.floor(#list/itemsPerPage)+1
    local out = "<green>===</green> <bold><blue>Blanket</blue><aqua>Con</aqua></bold> <green>=<hover:'<dark_red>?</dark_red>'><click:open_url:'https://www.youtube.com/watch?v=9lNZ_Rnr7Jc'>=</click></hover>=</green>\n"
    local max = itemsPerPage*page
    if max > #list then
        if max-itemsPerPage > #list then
            sendFeedback(context, "<red>Warp list ends at page "..maxPage.."</red>")
            return 0
        end
        max = #list
    elseif page < 1 then
        sendFeedback(context, "<red>There's no pages before the first, silly!</red>")
    end
    for i = 1+((itemsPerPage*page)-itemsPerPage), max do
        out = out..string.format(
                "- <hover:'<yellow>Click to warp!</yellow>'><run_command:'/warp %s'><green>%s</green></run_command></hover>\n",
                list[i].name,
                list[i].name
        )
    end
    sendFeedback(context,
            out.."<green>===</green> "..makeArrow("<<", page-1, maxPage)..
            " " ..tostring(page).. "/" ..tostring(maxPage).." "..
            makeArrow(">>", page+1, maxPage).." <green>===</green>"
    )
    return 1
end

-- If no page number is provided, list the first page
local listBuilder = CommandManager.literal("list"):executes(function(context)
    return listWarps(context, 1)
end)

-- If a page is passed in, handle it
listBuilder:m_then(CommandManager.argument("page", arguments.integer.integer(1)):executes(function(context)
    return listWarps(context, arguments.integer.getInteger(context, "page"))
end))

-- Add the list sub-command to the builder
builder:m_then(listBuilder)

-- Function that applies warp creation/modification functionality to a sub-command builder
local function warpCreator(b)
    return b:requires(function(source) -- Warps can only be created by players with the right permission level
        return source:hasPermissionLevel(2)
    end):m_then( -- Warps need a name, all other data can be obtained from the player
        CommandManager.argument("name", arguments.string.word()):executes(function(context)
            local pos = context:getSource():getPosition()
            local rot = context:getSource():getRotation()
            local name = arguments.string.getString(context, "name")

            local newWarp = {
                name = name,
                world = context:getSource():getWorld():getRegistryKey():getValue():toString(),
                x = pos:getX(),
                y = pos:getY(),
                z = pos:getZ(),
                pitch = rot.x,
                yaw = rot.y
            }

            local list = getWarps()
            for i = 1, #list do
                local warp = list[i]
                if warp.name == name then -- overwrite existing
                    list[i] = newWarp
                    sendFeedback(context, "<green>Warp "..name.." modified!</green>")
                    return 1
                end
            end
            warps[#warps+1] = newWarp
            flushWarps()
            sendFeedback(context, "<green>Warp "..name.." created!</green>")
            return 1
        end)
    )
end

local function warpRemover(b)
    return b:requires(function(source) -- Warps can also only be removed by players with the right permission level
        return source:hasPermissionLevel(2)
    end):m_then(
        CommandManager.argument("name", arguments.string.word()):executes(function(context)
            local name = arguments.string.getString(context, "name")
            local list = getWarps()
            for i = 1, #list do
                if list[i].name == name then -- found match
                    list[i] = nil -- bye bye
                    sendFeedback(context, "<green>Warp "..name.." deleted!</green>")
                    return 1
                end
            end
            flushWarps()
            sendFeedback(context, "<red>A warp named "..name.." does not exist to be removed</red>")
            return 1
        end)
    )
end

-- Attach all the argument builders to the root builder
builder
        :m_then(warpCreator(CommandManager.literal("add")))
        :m_then(warpCreator(CommandManager.literal("edit")))
        :m_then(warpRemover(CommandManager.literal("remove")))
        :m_then(CommandManager.argument("name", arguments.string.word()):executes(function(context)
            local name = arguments.string.getString(context, "name")
            local player = context:getSource():getPlayer()
            local locked = getLocked()
            if locked[player:getUuid():toString()] then
                sendFeedback(context, "<red>You are currently locked from warping. Leave the booth you're in to get unlocked. If you think this is an issue contact an admin.</red>")
                return 0
            end
            local list = getWarps()
            for i = 1, #list do -- Iterate over all warps
                local warp = list[i]
                if warp.name == name then -- If there's a match
                    player:teleport(game.getWorld(warp.world), warp.x, warp.y, warp.z, warp.yaw, warp.pitch)
                    return 1
                end
            end
            sendFeedback(context, "<red>A warp named '"..name.."' does not exist</red>")
            return 0
        end))
        :m_then(
            CommandManager.literal("lock")
            :requires(function(source) -- Locking can only be performed by an operator
                return source:hasPermissionLevel(2)
            end)
            :m_then(
                CommandManager.argument("player", arguments.entity.player())
                :executes(function(context)
                    player = arguments.entity.getPlayer(context, "player")
                    local locked = getLocked()
                    locked[player:getUuid():toString()] = true
                    flushLocked()
                    sendFeedback(context, "Locked "..player:getName():asString())
                    return 1
                end)
            )
        )
        :m_then(
            CommandManager.literal("unlock")
            :requires(function(source) -- Unlocking can only be performed by an operator
                return source:hasPermissionLevel(2)
            end)
            :m_then(
                CommandManager.argument("player", arguments.entity.player())
                :executes(function(context)
                    player = arguments.entity.getPlayer(context, "player")
                    local locked = getLocked()
                    locked[player:getUuid():toString()] = nil
                    flushLocked()
                    sendFeedback(context, "Unlocked "..player:getName():asString())
                    return 1
                end)
            )
        )
        :m_then(
            CommandManager.literal("toggleLock")
            :requires(function(source) -- Lock toggling can only be performed by an operator
                return source:hasPermissionLevel(2)
            end)
            :m_then(
                CommandManager.argument("player", arguments.entity.player())
                :executes(function(context)
                    player = arguments.entity.getPlayer(context, "player")
                    local locked = getLocked()
                    local uuid = player:getUuid():toString()
                    if locked[uuid] then
                        locked[uuid] = nil
                        sendFeedback(context, "Unlocked "..player:getName():asString())
                    else
                        locked[uuid] = true
                        sendFeedback(context, "Locked "..player:getName():asString())
                    end
                    flushLocked()
                    return 1
                end)
            )
        )
        :executes(function(context) -- make /warp by default list the first page of warps
            return listWarps(context, 1)
        end)

-- Register the command
command.register(builder)

--[[ WAILA COMMAND ]]--

command.register(CommandManager.literal("waila"):executes(function(context)
    local source = context:getSource()
    local player = source:getPlayer()

    -- Finally, use the block to get the identifier of the block, then pull the namespace from that
    local identifier = Registry.BLOCK:getId(
            -- Use the position to get the state, then the block attributed to that state
            source:getWorld():getBlockState(
                    -- Convert position to an actual BlockPos
                    BlockPos(
                            -- Get the block position the player is looking at <- START HERE read UP ^
                            player:raycast(5, 0, false):getBlockPos()
                    )
            ):getBlock()
    )
    local n = identifier:getNamespace()
    if n == "minecraft" and identifier:getPath() == "air" then
        sendFeedback(context, "<red>No block found, try getting closer</red>")
        return 0
    end
    local list = getWarps()
    local found = false
    local str = "You're looking at "..identifier:getPath().." from "
    for i = 1, #list do
        if string.lower(list[i].name) == n then
            str = str..string.format(
                    "<run_command:'/warp %s'><hover:'<yellow>Click here to visit %ss booth!</yellow>'><green><bold>%s</bold></green></hover></run_command>",
                    n, n, n
            )
            found = true
        end
    end
    if not found then
        str = str.."<hover:'Couldn't find a warp for this mod :('><gray><bold>"..n.."</bold></gray></hover>"
    end

    sendFeedback(context, str.."!")
    if found then
        return 1
    else
        return 0
    end
end))